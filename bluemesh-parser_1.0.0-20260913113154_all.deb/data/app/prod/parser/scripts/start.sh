#!/usr/bin/env bash
# start.sh — start the INSTALLED service via systemd.
#
# Not to be confused with run.sh, which is the app starter itself: run.sh execs the server in
# the foreground (it is what this unit's ExecStart runs, and what you use to run a dist tree by
# hand). This one just asks systemd to do that in the background.
set -euo pipefail
sudo systemctl start bluemesh-parser
echo "bluemesh-parser started. Logs: journalctl -u bluemesh-parser -f"

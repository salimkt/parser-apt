#!/usr/bin/env bash
sudo systemctl status bluemesh-parser --no-pager
echo ""
curl -sf http://localhost:8152/parser/health | python3 -m json.tool 2>/dev/null || echo "Service not responding on port 8152"

#!/usr/bin/env bash
# run.sh — start the service in the FOREGROUND. This is what systemd's ExecStart runs, and
# it is also how you start the app by hand from a release tree:
#
#   ./scripts/run.sh
#
# It exists because a hardened tree has two requirements that are easy to get wrong by hand:
#   * the compiled modules (app/config/…) are resolved from the tree ROOT, so the process must
#     start there with the root on sys.path — running `python main.py` from elsewhere fails;
#   * the .so are built for ONE OS/arch/CPython. Importing them anywhere else fails with a bare
#     "ModuleNotFoundError: No module named 'config'", which reads as a missing file rather than
#     the platform mismatch it actually is. The pre-flight below says which it is.
#
# exec, not a child process: systemd's Type=simple tracks the PID it starts, so the real server
# has to inherit it or restarts and shutdown signals go to the wrapper instead.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$HERE")"
cd "$ROOT"

# shellcheck disable=SC1091
[[ -f release.conf ]] && source ./release.conf
SERVICE="${SERVICE:-$(basename "$ROOT")}"

if [[ -x "$ROOT/.venv/bin/python" ]]; then
    PY="$ROOT/.venv/bin/python"
else
    PY="$(command -v python3 || true)"
    [[ -n "$PY" ]] || { echo "[run] no .venv and no python3 on PATH" >&2; exit 1; }
    echo "[run] WARNING: $ROOT/.venv is missing — falling back to $PY (run scripts/install.sh)" >&2
fi

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

# Pre-flight: can THIS interpreter actually import the compiled modules? Turns a confusing
# ModuleNotFoundError into the real reason, with both sides of the mismatch printed.
"$PY" - "$ROOT" <<'PYEOF' || exit $?
import glob, importlib.machinery, importlib.util, os, platform, sys
root = sys.argv[1]
os.chdir(root); sys.path.insert(0, root)
so = [os.path.basename(f) for f in glob.glob(os.path.join(root, "*.so"))]
if not so:
    sys.exit(0)                                   # a source tree, nothing to check
mods = sorted({f.split(".")[0] for f in so})
def _resolves_here(name):
    """The module must resolve to THIS tree, not merely to something importable. An unrelated
    `app` earlier on sys.path would otherwise satisfy the check and then shadow the compiled
    module at runtime — a failure that looks like the service running the wrong code."""
    try:
        spec = importlib.util.find_spec(name)
    except Exception:
        return False
    origin = getattr(spec, "origin", None) or ""
    return bool(spec) and os.path.realpath(origin).startswith(os.path.realpath(root) + os.sep)

missing = [m for m in mods if not _resolves_here(m)]
if not missing:
    sys.exit(0)
built = {}
try:
    for line in open(os.path.join(root, "BUILD")):
        k, _, v = line.strip().partition("=")
        built[k] = v
except OSError:
    pass
print("[run] ERROR: this build's compiled modules cannot be imported by this interpreter.",
      file=sys.stderr)
print(f"[run]   unimportable: {', '.join(missing)}", file=sys.stderr)
print(f"[run]   shipped     : {', '.join(so)}", file=sys.stderr)
print(f"[run]   built for   : platform={built.get('platform','?')} python={built.get('python','?')}",
      file=sys.stderr)
print(f"[run]   running on  : {platform.system().lower()}/{platform.machine()} "
      f"python={sys.version_info.major}.{sys.version_info.minor} ({sys.executable})", file=sys.stderr)
print("[run]   A .so is tied to the OS, CPU and CPython version it was compiled for. Either run",
      file=sys.stderr)
print("[run]   this build on a matching host, or rebuild with PLATFORM/PY set for this one",
      file=sys.stderr)
print("[run]   (see release.conf, then scripts/build_dist.sh).", file=sys.stderr)
sys.exit(3)
PYEOF

# START_CMD lets each service declare its own entry point (gunicorn vs `python main.py`)
# without this script needing to know which is which. $PY is substituted by the caller below.
if [[ -z "${START_CMD:-}" ]]; then
    if [[ -f gunicorn.conf.py ]]; then START_CMD='"$PY" -m gunicorn -c gunicorn.conf.py app:app'
    else                               START_CMD='"$PY" main.py'; fi
fi

echo "[run] $SERVICE starting from $ROOT with $PY"
eval "exec $START_CMD"

#!/usr/bin/env bash
set -euo pipefail
sudo systemctl stop bluemesh-parser
echo "bluemesh-parser stopped."

#!/usr/bin/env bash
journalctl -u bluemesh-parser -f

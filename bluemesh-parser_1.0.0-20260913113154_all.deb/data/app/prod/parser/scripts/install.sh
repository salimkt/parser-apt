#!/usr/bin/env bash
# install.sh — install the BlueMesh Parser Service on this machine.
#
# Usage: sudo ./scripts/install.sh [install-dir]
#   install-dir defaults to /data/app/prod/parser
set -euo pipefail

INSTALL_DIR="${1:-/data/app/prod/parser}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

[[ $EUID -ne 0 ]] && { echo "Run as root (sudo)." >&2; exit 1; }

echo "Installing BlueMesh Parser → $INSTALL_DIR"

# 1. Sync source
mkdir -p "$INSTALL_DIR"
# When the install dir IS the source tree, there is nothing to sync and rsync would
# copy the tree onto itself. That is the normal shape for a hardened release: the
# install dir is a CLONE of the release repo (see RELEASE.md), which is what lets
# scripts/upgrade.sh be a plain `git pull` + restart.
if [[ "$(cd "$SRC_DIR" && pwd)" != "$(cd "$INSTALL_DIR" && pwd)" ]]; then
    rsync -a --exclude='.git' --exclude='.venv' --exclude='__pycache__' \
             --exclude='*.pyc' "$SRC_DIR/" "$INSTALL_DIR/"
else
    echo "Install dir is the source tree (release-repo clone) — skipping sync."
fi

# 2. Ensure uv is available
if ! command -v uv &>/dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.cargo/bin:$PATH"
fi

# 3. Create venv and install deps via uv
echo "Installing dependencies with uv..."
uv venv "$INSTALL_DIR/.venv" --python 3.11
uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
    -r <(uv export --no-hashes --project "$INSTALL_DIR" 2>/dev/null) \
    || uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
        --project "$INSTALL_DIR" -e "$INSTALL_DIR"
apt-get update && apt-get install -y --no-install-recommends \
    gcc g++ libgl1 libglib2.0-0 libsm6 libxext6 libxrender1 libxcb1
echo "Dependencies installed."

# 4. Systemd unit
UNIT="/etc/systemd/system/bluemesh-parser.service"
sed "s|/opt/bluemesh/parser|$INSTALL_DIR|g" \
    "$INSTALL_DIR/bluemesh-parser.service" > "$UNIT"
systemctl daemon-reload
systemctl enable bluemesh-parser
echo "Systemd unit installed and enabled."
echo ""
echo "Start: systemctl start bluemesh-parser"
echo "Logs:  journalctl -u bluemesh-parser -f"

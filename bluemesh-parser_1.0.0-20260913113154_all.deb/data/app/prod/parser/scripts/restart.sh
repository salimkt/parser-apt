#!/usr/bin/env bash
set -euo pipefail
sudo systemctl restart bluemesh-parser
sudo systemctl status bluemesh-parser --no-pager
journalctl -u bluemesh-parser -f

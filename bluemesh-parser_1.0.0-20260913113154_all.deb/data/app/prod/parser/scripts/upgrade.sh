#!/usr/bin/env bash
# upgrade.sh — pull the latest hardened build from the release repo and restart the service.
# Ships INSIDE the release tree, so the deployed copy can always upgrade itself.
#
#   sudo ./scripts/upgrade.sh                  # pull + restart if the repo is ahead
#   sudo ./scripts/upgrade.sh --force          # reinstall even if already current
#   sudo ./scripts/upgrade.sh --check          # report only, change nothing
#
# The install dir IS a clone of the release repo, so "upgrade" is `git pull` plus a restart.
# Everything else here exists because a failed upgrade on a running service is worse than no
# upgrade: we snapshot first, keep local config, verify health after, and roll back if the
# new build does not come up.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$HERE")"
cd "$ROOT"

# shellcheck disable=SC1091
[[ -f release.conf ]] && source ./release.conf
SERVICE="${SERVICE:-$(basename "$ROOT")}"
UNIT="${UNIT:-bluemesh-$SERVICE}"
HEALTH_PATH="${HEALTH_PATH:-/health}"
PORT="${PORT:-}"
MODE="${1:-}"

log() { printf '[upgrade] %s\n' "$*"; }
die() { printf '[upgrade] ERROR: %s\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "run as root (systemctl restart needs it)"
[[ -d .git ]] || die "$ROOT is not a git clone of the release repo — install with scripts/install.sh first"

git config --global --add safe.directory "$ROOT" 2>/dev/null || true

log "fetching $(git config --get remote.origin.url || echo '<no origin>')"
git fetch --quiet origin
BRANCH="$(git rev-parse --abbrev-ref HEAD)"
LOCAL="$(git rev-parse HEAD)"
REMOTE="$(git rev-parse "origin/$BRANCH")"

if [[ "$LOCAL" == "$REMOTE" && "$MODE" != "--force" ]]; then
    log "already current ($(git rev-parse --short HEAD)) — nothing to do"
    exit 0
fi
if [[ "$MODE" == "--check" ]]; then
    log "update available: $(git rev-parse --short HEAD) -> $(git rev-parse --short "origin/$BRANCH")"
    exit 0
fi

# Refuse a tree built for a different interpreter/platform than this host's venv. Without
# this the pull "works" and the service then dies on `undefined symbol`, which reads as a
# code bug rather than an ABI mismatch.
if [[ -f BUILD && -x .venv/bin/python ]]; then
    # A tree can carry .so for SEVERAL interpreters (python=3.11,3.12) — accept the venv's
    # version if it is any of them. Comparing against one value refused a perfectly good build.
    want="$(sed -n 's/^python=//p' BUILD)"
    have="$(.venv/bin/python -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
    if [[ -n "$want" ]] && ! printf '%s' ",$want," | grep -q ",$have,"; then
        die "this build carries python $want but the venv is $have — rebuild with PY_VERSIONS including $have, or recreate the venv on one of $want"
    fi
fi

TS="$(date -u +%Y%m%d-%H%M%S)"
BACKUP="/var/backups/bluemesh/${SERVICE}-${TS}.tar.gz"
mkdir -p "$(dirname "$BACKUP")"
log "snapshotting current install -> $BACKUP"
tar czf "$BACKUP" --exclude='./.venv' --exclude='./.git' -C "$ROOT" . 2>/dev/null || \
    die "backup failed — refusing to upgrade without one"

# Local config must survive an upgrade: settings.yml is operational state, not code. Stash it,
# let git take the new tree, then put it back and leave the incoming one alongside for review.
STASHED=""
if [[ -f settings.yml ]] && ! git diff --quiet -- settings.yml 2>/dev/null; then
    cp settings.yml "/tmp/${SERVICE}-settings.local.$TS"; STASHED="/tmp/${SERVICE}-settings.local.$TS"
    log "local settings.yml differs from the repo — preserving it"
fi

OLD_LOCK_SUM="$( [[ -f uv.lock ]] && sha256sum uv.lock | cut -d' ' -f1 || echo none)"

log "updating $LOCAL -> $REMOTE"
git checkout --quiet -- . 2>/dev/null || true      # drop tracked-file drift so the pull is clean
git pull --quiet --ff-only origin "$BRANCH" || die "pull failed (diverged? run: git reset --hard origin/$BRANCH)"

if [[ -n "$STASHED" ]]; then
    cp settings.yml settings.yml.incoming 2>/dev/null || true
    cp "$STASHED" settings.yml
    log "kept your settings.yml; the new one is at settings.yml.incoming"
fi

# Dependencies only change when the lock does; reinstalling every time would turn a 5-second
# restart into minutes of downtime for nothing.
NEW_LOCK_SUM="$( [[ -f uv.lock ]] && sha256sum uv.lock | cut -d' ' -f1 || echo none)"
if [[ "$OLD_LOCK_SUM" != "$NEW_LOCK_SUM" ]]; then
    log "uv.lock changed — refreshing dependencies"
    if command -v uv >/dev/null; then
        uv pip install --python "$ROOT/.venv/bin/python" -r <(uv export --no-hashes --project "$ROOT") \
            || log "WARNING: dependency refresh failed; the service may not start"
    else
        log "WARNING: uv not found — dependencies NOT refreshed"
    fi
fi

log "restarting $UNIT"
systemctl daemon-reload 2>/dev/null || true
systemctl restart "$UNIT"

# Verify it actually came up. A restart that exits non-zero, or a port that never answers, is
# the case where rolling back matters most.
ok=0
for i in $(seq 1 30); do
    if systemctl is-active --quiet "$UNIT"; then
        if [[ -z "$PORT" ]]; then ok=1; break; fi
        if curl -fsS --max-time 3 "http://127.0.0.1:${PORT}${HEALTH_PATH}" >/dev/null 2>&1; then ok=1; break; fi
    fi
    sleep 2
done

if [[ "$ok" != "1" ]]; then
    log "the new build did not come up — ROLLING BACK to $BACKUP"
    systemctl stop "$UNIT" || true
    tar xzf "$BACKUP" -C "$ROOT"
    systemctl start "$UNIT" || true
    systemctl is-active --quiet "$UNIT" && log "rolled back and running" || log "ROLLBACK ALSO FAILED — manual attention needed"
    die "upgrade failed; previous version restored from $BACKUP"
fi

log "now on $(git rev-parse --short HEAD) ($(sed -n 's/^version=//p' BUILD 2>/dev/null || echo '?')) — $UNIT healthy"

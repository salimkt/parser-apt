"""Dev entry point — single-process uvicorn from settings.yml / env vars.

PRODUCTION runs under gunicorn, which owns the shared GPU model pool at the master level and forks
many async HTTP workers that dispatch to it:

    gunicorn -c gunicorn.conf.py app:app

This dev path is intentionally SINGLE-PROCESS: that one process both owns the shared model pool
(created in the app lifespan via ensure_started) and serves HTTP. Multiple uvicorn workers here
would each try to own their own pool (there's no master to share one), so we pin workers=1 — plenty
for local dev. Scale out with gunicorn, not this.
"""
import uvicorn
from config import svc

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host=svc.HOST,
        port=svc.PORT,
        workers=1,          # single process owns the shared pool in dev; use gunicorn to scale HTTP
        log_level=svc.LOG_LEVEL,
        loop="uvloop",
        http="httptools",
        access_log=True,
    )

# BlueMesh parser — install & upgrade

This tree is a **hardened build**: the service's own modules ship as compiled `.so`, not
Python source. `main.py` (and, for the parser, `gunicorn.conf.py`) stay readable because
systemd executes them directly — a compiled module cannot be run that way.

`BUILD` records the version, source commit and the exact ABI this tree was compiled for.
`HARDEN.log` lists what was compiled.

## First install

```bash
sudo git clone <this-repo-url> /data/app/prod/parser
cd /data/app/prod/parser
sudo ./scripts/install.sh        # builds .venv from uv.lock, installs the systemd unit
sudo systemctl enable --now bluemesh-parser
curl -fsS http://127.0.0.1:8152/parser/health
```

The install dir is the git clone itself — that is what makes upgrades a `git pull`.
`install.sh` notices this and skips its own file sync.

## Running it

`scripts/run.sh` is the starter — it is what the systemd unit executes, and it is how you run
the service by hand:

```bash
./scripts/run.sh                      # foreground
sudo systemctl start bluemesh-parser   # under systemd (same script)
curl -fsS http://127.0.0.1:8152/parser/health
```

Do **not** run `python main.py` directly from an arbitrary directory. The compiled modules are
imported from the tree root, so the process has to start there with the root on `PYTHONPATH`;
`run.sh` does that, picks `.venv/bin/python`, and `exec`s the server so systemd keeps tracking
the right PID.

### This build only runs on the platform it was compiled for

A `.so` is tied to the OS, CPU architecture **and** CPython minor version it was built against —
see `platform=` and `python=` in `BUILD`. Run it anywhere else and Python simply does not see
the module, which surfaces as a bare `ModuleNotFoundError: No module named 'config'` that looks
like a missing file. `run.sh` checks this first and prints what was built versus what you are
running instead. Trying a `linux/amd64` + py3.11 build on a macOS/arm64 + py3.10 machine is the
common case, and it cannot work — use a matching host, or rebuild with `PLATFORM`/`PY` set for
the machine you want to run on.

You do not need to `uv sync` inside this tree: `scripts/install.sh` creates `.venv` from
`uv.lock` as part of installation.

## Upgrading

```bash
sudo ./scripts/upgrade.sh            # pull if the repo is ahead, then restart
sudo ./scripts/upgrade.sh --check    # report only, change nothing
sudo ./scripts/upgrade.sh --force    # reinstall the current commit
```

It is written for a service that is already serving traffic:

1. **Refuses an ABI mismatch** — if `BUILD`'s python version differs from `.venv`'s, it stops
   with a readable message rather than letting the service die on `undefined symbol`.
2. **Snapshots first** to `/var/backups/bluemesh/parser-<timestamp>.tar.gz`, and aborts if the
   snapshot cannot be written.
3. **Keeps your `settings.yml`.** Local config is not code; the incoming version is saved
   beside it as `settings.yml.incoming` for you to compare.
4. **Reinstalls dependencies only when `uv.lock` changed**, so a normal release is a restart
   rather than minutes of downtime.
5. **Verifies `http://127.0.0.1:8152/parser/health` after restart and ROLLS BACK** from the snapshot if
   the new build does not come up.

## If an upgrade fails

It rolls back on its own and tells you which snapshot it used. To do it by hand:

```bash
sudo systemctl stop bluemesh-parser
sudo tar xzf /var/backups/bluemesh/parser-<timestamp>.tar.gz -C /data/app/prod/parser
sudo systemctl start bluemesh-parser
```

## Other scripts

`scripts/`: `status.sh`, `logs.sh`, `restart.sh`, `stop.sh` — thin wrappers over
`systemctl`/`journalctl` for `bluemesh-parser`.

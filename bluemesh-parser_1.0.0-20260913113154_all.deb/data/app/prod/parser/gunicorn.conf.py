"""Gunicorn config for the BlueMesh Parser — the production process manager.

Architecture (single VRAM-resident model tier + high-traffic HTTP tier):
  • The gunicorn arbiter (master) starts ONE shared pool of `parse_workers` Docling model instances
    in the `on_starting` hook — BEFORE it forks any HTTP worker. Each worker pins to one GPU
    (round-robin over `cuda_device`) and loads the model (layout + RapidOCR, + the figure VLM path)
    once. So model VRAM is a function of parse_workers, never of HTTP worker count.
  • `preload_app` then imports the app once and forks N async UvicornWorkers. Each forked worker
    INHERITS the shared job queue + manager, mints its own result queue, and dispatches parse jobs
    to the pool — it never loads Docling itself. This is why `workers` can be raised for HTTP
    concurrency without duplicating the model.
  • The master stays CUDA-clean (GPUs are probed via nvidia-smi, never torch), so forking both the
    model instances and the HTTP workers from it is safe.

Scaling knobs:
  • service.workers      → HTTP concurrency (async accept/dispatch/merge). Raise for traffic.
  • parser.cuda_device   → which GPUs host workers ("0" / "0,1,2" / "cpu").
  • parser.parse_workers → number of parse processes = parse concurrency (VRAM-bound), spread over
                           cuda_device round-robin.

Run:  gunicorn -c gunicorn.conf.py app:app
Tune via settings.yml / env: SERVICE_WORKERS, SERVICE_REQUEST_TIMEOUT_S, PARSER_* , STT_*.
"""
from config import svc

# UvicornWorker auto-selects uvloop + httptools when installed (both are deps).
wsgi_app = "app:app"
bind = f"{svc.HOST}:{svc.PORT}"
worker_class = "uvicorn.workers.UvicornWorker"
# HTTP tier only — these are async and offload all parsing to the shared GPU pool, so this scales
# request concurrency independently of the (fixed, VRAM-bound) number of model instances.
workers = max(1, svc.WORKERS)

# Import the app once in the master and fork workers (COW). REQUIRED here: the shared pool's job
# queue + manager are created in the master (on_starting) and must be inherited by the forked
# workers. The master itself never loads Docling/torch, so this stays CUDA-fork-safe.
preload_app = True

# Long parses/transcriptions: the loop stays responsive (heavy work is off in the pool / async
# HTTP), so this timeout only reaps genuinely hung workers.
timeout = svc.REQUEST_TIMEOUT_S
graceful_timeout = 30
keepalive = 15

# Recycle the light HTTP workers periodically to bound any slow leak. The GPU model instances are
# owned by the master and stay warm across HTTP-worker recycles.
max_requests = 1000
max_requests_jitter = 100

loglevel = svc.LOG_LEVEL
accesslog = "-"
errorlog = "-"
proc_name = svc.NAME


# ── server hooks: own the shared GPU model pool at the master level ────────────────

def on_starting(server):
    """Master process, before any worker is forked: download models (once) and start the ONE shared
    pool of GPU model instances. Forked HTTP workers then inherit its job queue + manager."""
    import parser_core
    parser_core.warm()
    parser_core.start_gpu_pool()


def on_exit(server):
    """Master shutdown: stop the shared model instances and the manager."""
    import parser_core
    parser_core.shutdown_pool()

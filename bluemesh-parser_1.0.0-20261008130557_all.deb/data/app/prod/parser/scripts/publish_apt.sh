#!/usr/bin/env bash
# publish_apt.sh — publish the .deb as a real APT REPOSITORY in the release repo.
#
#   scripts/publish_apt.sh                # build (if needed), index, commit, push
#   scripts/publish_apt.sh --dry-run      # do everything except commit/push
#
# Separate from publish.sh on purpose. publish.sh pushes the runnable dist/ tree, whose
# consumer is a host that git-pulls and restarts. This pushes an apt repo in the archive in the
# SAME release repo, whose consumer is dpkg. They have different layouts, different update
# mechanics and different failure modes, so keeping them in one script would mean one of the
# two is always the awkward special case.
#
# The result is a FLAT repository — the simplest form apt understands — served straight off
# raw.githubusercontent.com, so there is no package server to run:
#
#   echo 'deb [trusted=yes] https://raw.githubusercontent.com/<owner>/<repo>/main/apt ./' \
#        | sudo tee /etc/apt/sources.list.d/bluemesh.list
#   sudo apt update && sudo apt install bluemesh-<service>
#
# trusted=yes because the index is unsigned: signing needs a GPG key with a private half that
# would have to live in CI. If you want it signed, add a key and a Release.gpg/InRelease step
# here — the layout does not otherwise change.
#
# OLD VERSIONS ARE KEPT. apt upgrades by comparing versions in the index, so dropping the
# previous .deb would leave anyone pinned to it unable to install.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$HERE")"
cd "$ROOT"

# shellcheck disable=SC1091
source ./release.conf
: "${SERVICE:?}"
# The apt archive is its own repo: dpkg consumes it, so it must not share a branch
# with the runnable dist/ tree that hosts git-pull. Falls back to RELEASE_REPO for
# a setup that never split them.
APT_REPO="${APT_REPO:-${RELEASE_REPO:?set APT_REPO or RELEASE_REPO}}"
APT_BRANCH="${APT_BRANCH:-${RELEASE_BRANCH:-main}}"
PKG="bluemesh-$SERVICE"
DRY=""; [[ "${1:-}" == "--dry-run" ]] && DRY=1

log() { printf '[apt] %s\n' "$*"; }
die() { printf '[apt] ERROR: %s\n' "$*" >&2; exit 1; }

shopt -s nullglob
DEBS=(build/*.deb)
[[ ${#DEBS[@]} -gt 0 ]] || { log "no .deb in build/ — building one"; ./scripts/build_deb.sh; DEBS=(build/*.deb); }
[[ ${#DEBS[@]} -gt 0 ]] || die "build/ still has no .deb"

# Credentials, exactly as publish.sh handles them: read from .env, never echoed, never written
# into .git/config and never placed in a remote URL (where every later error would print it).
ENVFILE=""; for c in .env ../.env; do [[ -f "$c" ]] && { ENVFILE="$c"; break; }; done
if [[ -n "$ENVFILE" ]]; then
    log "reading credentials from $ENVFILE"
    GIT_TOKEN="${GIT_TOKEN:-$(grep -E '^\s*GIT_TOKEN=' "$ENVFILE" | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)}"
    GITHUB_TOKEN="${GITHUB_TOKEN:-$(grep -E '^\s*GITHUB_TOKEN=' "$ENVFILE" | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)}"
    GIT_SSH_KEY="${GIT_SSH_KEY:-$(grep -E '^\s*GIT_SSH_KEY=' "$ENVFILE" | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)}"
fi
TOKEN="${GIT_TOKEN:-${GITHUB_TOKEN:-}}"
if [[ -z "$DRY" ]]; then
    [[ -n "$TOKEN" || -n "${GIT_SSH_KEY:-}" ]] || \
        die "no credentials: put GIT_TOKEN=… (or GIT_SSH_KEY=/path) in .env — see .env.example"
fi

WORK="$(mktemp -d)"; STAGE="$WORK/release"
trap 'rm -rf "$WORK"' EXIT

if [[ -n "${GIT_SSH_KEY:-}" && -z "$TOKEN" ]]; then
    [[ -f "$GIT_SSH_KEY" ]] || die "GIT_SSH_KEY=$GIT_SSH_KEY does not exist"
    PUSH_URL="$(echo "$APT_REPO" | sed -E 's#https://github.com/#git@github.com:#')"
    export GIT_SSH_COMMAND="ssh -i $GIT_SSH_KEY -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"
    log "auth: ssh key"
elif [[ -n "$TOKEN" ]]; then
    PUSH_URL="$APT_REPO"
    printf '%s' "$TOKEN" > "$WORK/.tok"; chmod 600 "$WORK/.tok"
    ASKPASS="$WORK/askpass"; chmod 700 "$WORK" 
    printf '#!/bin/sh\ncase "$1" in *Username*) echo "x-access-token";; *) cat "%s";; esac\n' "$WORK/.tok" > "$ASKPASS"
    chmod 700 "$ASKPASS"
    export GIT_ASKPASS="$ASKPASS" GIT_TERMINAL_PROMPT=0
    log "auth: https token (never written to .git/config)"
else
    PUSH_URL="$APT_REPO"; log "auth: none (--dry-run)"
fi

log "cloning $APT_REPO"
if ! git clone --quiet --depth 1 --branch "$APT_BRANCH" "$PUSH_URL" "$STAGE" 2>/dev/null; then
    log "no $APT_BRANCH yet — initialising"
    mkdir -p "$STAGE"; git -C "$STAGE" init --quiet -b "$APT_BRANCH"
    git -C "$STAGE" remote add origin "$PUSH_URL" 2>/dev/null || true
fi

for d in "${DEBS[@]}"; do cp "$d" "$STAGE/"; log "adding $(basename "$d")"; done

# Index with dpkg-scanpackages. Run in a container because it does not exist on macOS, and so
# the index is produced by the same dpkg tooling apt will read it with.
log "generating the package index"
docker run --rm -v "$STAGE":/apt -w /apt debian:bookworm-slim sh -ec '
    apt-get -qq update >/dev/null && apt-get -qq install -y dpkg-dev >/dev/null
    dpkg-scanpackages --multiversion . /dev/null > Packages
    gzip -9kf Packages
    {
      echo "Archive: stable"; echo "Origin: BlueMesh"; echo "Label: BlueMesh"
      echo "Suite: stable"; echo "Codename: bluemesh"
      echo "Date: $(date -uR)"
      echo "Architectures: all amd64 arm64"; echo "Components: main"
      echo "Description: BlueMesh service packages"
      echo "MD5Sum:"
      for f in Packages Packages.gz; do echo " $(md5sum $f | cut -d\  -f1) $(stat -c%s $f) $f"; done
      echo "SHA256:"
      for f in Packages Packages.gz; do echo " $(sha256sum $f | cut -d\  -f1) $(stat -c%s $f) $f"; done
    } > Release
' >/dev/null || die "indexing failed (dpkg-scanpackages) — nothing pushed"
# An empty index still parses, so apt reports "Unable to locate package" instead of an error.
N_DEBS=$(find "$STAGE" -maxdepth 1 -name '*.deb' | wc -l | tr -d ' ')
N_IDX=$(grep -c '^Package:' "$STAGE/Packages" || true)
[[ "$N_IDX" == "$N_DEBS" ]] || die "index lists $N_IDX package(s) but the archive holds $N_DEBS .deb — nothing pushed"
log "indexed $N_IDX package version(s)"

RAW_BASE="$(echo "$APT_REPO" | sed -E 's#https://github.com/([^/]+)/([^/.]+)(\.git)?#https://raw.githubusercontent.com/\1/\2#')/$APT_BRANCH"
cat > "$STAGE/README.md" <<APTDOC
# BlueMesh apt repository

\`\`\`bash
echo 'deb [trusted=yes] $RAW_BASE ./' | sudo tee /etc/apt/sources.list.d/bluemesh.list
sudo apt update
sudo apt install $PKG
\`\`\`

Flat, unsigned repository (\`trusted=yes\`) — see scripts/publish_apt.sh for why.
Older versions are retained so a pinned install keeps working.
APTDOC

cd "$STAGE"
git add -A
if git diff --cached --quiet; then log "index already current — nothing to push"; exit 0; fi
log "staged $(git diff --cached --name-only | wc -l | tr -d ' ') path(s) in the archive"

if [[ -n "$DRY" ]]; then
    git diff --cached --name-only | sed 's/^/   /'
    log "--dry-run: not committing or pushing"
    log "sources.list line would be:  deb [trusted=yes] $RAW_BASE ./"
    exit 0
fi

VERSION="$(sed -nE 's/^version[[:space:]]*=[[:space:]]*"([^"]+)".*/\1/p' "$ROOT/pyproject.toml" | head -1)"
git -c user.name="${GIT_AUTHOR_NAME:-bluemesh-release}" \
    -c user.email="${GIT_AUTHOR_EMAIL:-release@bluemesh.local}" \
    commit --quiet -m "apt: $PKG $VERSION"
git push --quiet origin "$APT_BRANCH"
log "pushed. On the target:"
echo "   echo 'deb [trusted=yes] $RAW_BASE ./' | sudo tee /etc/apt/sources.list.d/bluemesh.list"
echo "   sudo apt update && sudo apt install $PKG"

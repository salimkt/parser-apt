#!/usr/bin/env bash
# Build an apt-installable .deb of the hardened release tree into ./build.
#
#   scripts/build_deb.sh                 # build dist/ if needed, then package it
#   scripts/build_deb.sh --out build     # where the .deb lands (default: build/)
#
# Install on any Debian/Ubuntu host with:  sudo apt install ./build/<file>.deb
#
# Architecture: all — ON PURPOSE. The tree carries a .so per (platform, python) and CPython
# picks its own by extension suffix, so ONE package installs correctly on x86_64 and on
# aarch64 (e.g. an NVIDIA DGX). dpkg would normally want one .deb per architecture; that
# would mean two artifacts to build, publish and keep in step for zero functional gain here.
# The darwin .so are dropped — they are dead weight inside a .deb.
#
# The Python dependencies are NOT debian packages: they are pinned in requirements.txt
# (exported from uv.lock at build time) and installed into a venv by postinst, so the target
# needs nothing but python3 + pip. That step needs network; if it fails the package still
# installs and prints how to finish it.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$HERE")"
cd "$ROOT"

# shellcheck disable=SC1091
source ./release.conf
: "${SERVICE:?}"; : "${UNIT:?}"; : "${PORT:?}"
OUT="build"
[[ "${1:-}" == "--out" ]] && { OUT="$2"; shift 2; }

PKG="bluemesh-$SERVICE"
VERSION="$(sed -nE 's/^version[[:space:]]*=[[:space:]]*"([^"]+)".*/\1/p' pyproject.toml | head -1)"
VERSION="${VERSION:-0.0.0}"
# apt upgrades by VERSION COMPARISON, so republishing the same pyproject version is
# invisible to it — measured: dpkg --compare-versions 1.0.0 lt 1.0.0 is false. Append a
# UTC-timestamp debian revision so each build is strictly newer, while a real bump of the
# upstream version still wins over any revision (1.0.1-<old ts> > 1.0.0-<new ts>).
DEB_VERSION="${VERSION}-${DEB_REVISION:-$(date -u +%Y%m%d%H%M%S)}"
INSTALL_DIR="/data/app/prod/$SERVICE"

[[ -d dist && -n "$(ls dist/*.so 2>/dev/null)" ]] || { echo "── dist/ missing; building it first"; ./scripts/build_dist.sh; }

PYS="$(sed -n 's/^python=//p' dist/BUILD | tr ',' ' ')"
echo "── packaging $PKG $DEB_VERSION  (python: $PYS, install dir: $INSTALL_DIR)"

STAGE="$(mktemp -d)/pkg"
mkdir -p "$STAGE/DEBIAN" "$STAGE$INSTALL_DIR" "$STAGE/lib/systemd/system" "$STAGE/usr/bin"

# Payload = the runnable tree, minus what a linux box cannot use or must not receive.
# A local run leaves a .venv (and caches) inside dist/ — run.sh prefers it — so the packager
# cannot assume dist/ is pristine. Copy only what belongs in the package: measured a 754MB
# leftover venv turning a 1.7MB tree into a 112MB .deb.
tar --exclude='./.venv' --exclude='./__pycache__' --exclude='./build' --exclude='./dist' \
    --exclude='./.git' --exclude='./.gitignore' --exclude='*.pyc' \
    --exclude='*.egg-info' --exclude='./.pytest_cache' \
    -cf - -C dist . | tar -xf - -C "$STAGE$INSTALL_DIR"
rm -f "$STAGE$INSTALL_DIR"/*darwin.so
rm -f "$STAGE$INSTALL_DIR/bluemesh-$SERVICE.service"      # it belongs in /lib/systemd/system
cp "dist/bluemesh-$SERVICE.service" "$STAGE/lib/systemd/system/$UNIT.service"

# Pin the Python deps now, so the target needs no uv and no resolver.
uv export --no-hashes --no-emit-project --format requirements-txt > "$STAGE$INSTALL_DIR/requirements.txt" 2>/dev/null \
  || { echo "   WARNING: uv export failed — falling back to uv.lock on the target"; : > "$STAGE$INSTALL_DIR/requirements.txt"; }
echo "   deps pinned: $(grep -vc '^#' "$STAGE$INSTALL_DIR/requirements.txt") packages"

INSTALLED_SIZE=$(( $(du -sk "$STAGE" | cut -f1) ))

cat > "$STAGE/DEBIAN/control" <<CONTROL
Package: $PKG
Version: $DEB_VERSION
Section: net
Priority: optional
Architecture: all
Depends: python3 (>= 3.11), python3-venv, python3-pip
Recommends: curl
Maintainer: BlueMesh <release@bluemesh.local>
Installed-Size: $INSTALLED_SIZE
Description: BlueMesh $SERVICE service (hardened build)
 Ships the service as compiled CPython extensions rather than readable source.
 One package serves x86_64 and aarch64: an extension's filename encodes the
 platform and interpreter, so each host loads only the .so built for it.
 .
 Installs to $INSTALL_DIR and registers the $UNIT systemd unit on port $PORT.
 Python dependencies are installed into a private virtualenv by the post-install
 step; that requires network access.
CONTROL

# settings.yml is operator state, not code: listing it as a conffile makes dpkg preserve
# local edits across upgrades and ask before replacing it, instead of overwriting silently.
echo "$INSTALL_DIR/settings.yml" > "$STAGE/DEBIAN/conffiles"

# A retryable setup command, so a failed (or skipped) dependency install is fixable without
# reinstalling the package.
cat > "$STAGE/usr/bin/$PKG-setup" <<SETUP
#!/bin/sh
# Create/refresh the virtualenv for $PKG from its pinned requirements.
#   $PKG-setup --hf-token TOKEN   validate a Hugging Face token against huggingface.co and
#                                 store it root-only in /etc/bluemesh/hf.env (shared by the
#                                 BlueMesh services); an invalid/expired token exits non-zero.
set -e
if [ "\${1:-}" = "--hf-token" ]; then
    T="\${2:-}"
    case "\$T" in hf_*) ;; *) echo "❌ HF token must start with hf_" >&2; exit 1 ;; esac
    command -v curl >/dev/null 2>&1 || { echo "❌ curl is required to validate the HF token" >&2; exit 1; }
    CODE=\$(curl -s -o /dev/null -m 20 -w '%{http_code}' -H "Authorization: Bearer \$T" https://huggingface.co/api/whoami-v2 || true)
    case "\$CODE" in
        200) ;;
        401) echo "❌ HF token rejected by huggingface.co (invalid or expired)" >&2; exit 1 ;;
        *)   echo "❌ could not validate the HF token (HTTP \${CODE:-none}) — check network" >&2; exit 1 ;;
    esac
    install -d -m 700 /etc/bluemesh
    (umask 077; printf 'HF_TOKEN=%s\n' "\$T" > /etc/bluemesh/hf.env)
    echo "✅ HF token valid — stored in /etc/bluemesh/hf.env (root-only)"
    if [ -d /run/systemd/system ] && systemctl is-active --quiet $UNIT; then
        systemctl restart $UNIT && echo "🔄 restarted $UNIT"
    fi
    exit 0
fi
DIR="$INSTALL_DIR"
for v in $PYS; do
    if command -v "python\$v" >/dev/null 2>&1; then PY="python\$v"; break; fi
done
if [ -z "\${PY:-}" ]; then
    echo "No supported interpreter found (need one of: $PYS)." >&2
    echo "The compiled modules only load on those versions." >&2
    exit 1
fi
echo "Using \$PY -> \$DIR/.venv"
"\$PY" -m venv "\$DIR/.venv"
"\$DIR/.venv/bin/pip" install --quiet --upgrade pip
"\$DIR/.venv/bin/pip" install -r "\$DIR/requirements.txt"
echo "Dependencies installed. Start with: systemctl start $UNIT"
SETUP
chmod 755 "$STAGE/usr/bin/$PKG-setup"

cat > "$STAGE/DEBIAN/postinst" <<POSTINST
#!/bin/sh
set -e
case "\$1" in
  configure)
    chmod 755 $INSTALL_DIR/scripts/*.sh 2>/dev/null || true
    # Optional HF token:  sudo HF_TOKEN=hf_… apt install $PKG
    # Unlike the dependency step this DOES fail the install: a token that was given but is
    # invalid would otherwise surface hours later as a 401 on the first model download.
    if [ -n "\${HF_TOKEN:-}" ]; then
        $PKG-setup --hf-token "\$HF_TOKEN" || { echo "$PKG: HF token invalid — install stopped. Re-run with a valid HF_TOKEN." >&2; exit 1; }
    fi
    # Dependency install needs the network and can take a long time (torch, docling).
    # It must NOT fail the package: a half-configured package blocks every later apt run,
    # and the fix is a single retryable command.
    if [ "\${BLUEMESH_SKIP_VENV:-0}" = "1" ]; then
        echo "$PKG: BLUEMESH_SKIP_VENV=1 — skipping virtualenv setup."
    elif ! $PKG-setup; then
        echo ""
        echo "$PKG: dependency install did not complete."
        echo "  Fix connectivity, then run:  sudo $PKG-setup"
        echo ""
    fi
    if [ -d /run/systemd/system ]; then
        systemctl daemon-reload || true
        systemctl enable $UNIT >/dev/null 2>&1 || true
        echo "$PKG: enabled. Start it with:  sudo systemctl start $UNIT"
        echo "$PKG: health check:            curl -fsS http://127.0.0.1:$PORT$HEALTH_PATH"
    fi
    ;;
esac
exit 0
POSTINST

cat > "$STAGE/DEBIAN/prerm" <<PRERM
#!/bin/sh
set -e
if [ -d /run/systemd/system ]; then
    systemctl stop $UNIT >/dev/null 2>&1 || true
    [ "\$1" = "remove" ] && systemctl disable $UNIT >/dev/null 2>&1 || true
fi
exit 0
PRERM

cat > "$STAGE/DEBIAN/postrm" <<POSTRM
#!/bin/sh
set -e
[ -d /run/systemd/system ] && systemctl daemon-reload || true
if [ "\$1" = "purge" ]; then
    # The venv and any downloaded models are NOT package files, so dpkg will not remove
    # them; purge is the only point where destroying them is what the operator asked for.
    rm -rf $INSTALL_DIR/.venv
    rmdir $INSTALL_DIR 2>/dev/null || true
fi
exit 0
POSTRM
chmod 755 "$STAGE/DEBIAN/postinst" "$STAGE/DEBIAN/prerm" "$STAGE/DEBIAN/postrm"

mkdir -p "$OUT"
DEB="$OUT/${PKG}_${DEB_VERSION}_all.deb"
# dpkg-deb is not on macOS; build in a container so the same command works everywhere.
# --root-owner-group keeps root:root ownership without needing fakeroot or sudo.
if command -v dpkg-deb >/dev/null; then
    dpkg-deb --root-owner-group --build "$STAGE" "$DEB" >/dev/null
else
    docker run --rm -v "$(dirname "$STAGE")":/s -v "$ROOT/$OUT":/out debian:bookworm-slim \
        sh -c "dpkg-deb --root-owner-group --build /s/pkg /out/$(basename "$DEB")" >/dev/null
fi
rm -rf "$(dirname "$STAGE")"

echo
echo "── $DEB  ($(du -h "$DEB" | cut -f1))"
echo "   install:  sudo apt install ./$DEB"
echo "   then:     sudo systemctl start $UNIT"
